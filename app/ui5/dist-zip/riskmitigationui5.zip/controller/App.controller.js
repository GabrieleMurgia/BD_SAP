sap.ui.define(["sap/ui/core/mvc/Controller"],i=>{"use strict";return i.extend("riskmitigation.ui5.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map